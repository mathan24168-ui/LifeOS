# Building LifeOS AI (Flutter App) — Complete Instructions

This document walks through your machine performing every step you
requested: installing dependencies, configuring the Android build,
generating a signed release APK, and installing it — plus exactly why
those steps couldn't be executed inside the sandbox that generated this
code (see "Why this wasn't built for you" at the bottom).

## Prerequisites (one-time, on your machine)

- Flutter SDK 3.24+ (`flutter --version`)
- Android SDK + a JDK 17 (Android Studio installs both)
- An Android emulator or a physical device with USB debugging enabled

## Step 0 — one-time Android scaffolding fix

This project ships every Android file **except** the Gradle wrapper's
binary jar (`gradle/wrapper/gradle-wrapper.jar`), because that file has to
be downloaded from Gradle's servers and this build environment has no
network access. Fix it with one command from the project root:

```bash
cd lifeos_ai
flutter build apk --release
```

Flutter's own tooling bootstraps `gradle-wrapper.jar` automatically the
first time you build if it's missing — this is standard, documented
Flutter/Gradle behavior, not a workaround. If for any reason it doesn't,
run this instead before building:

```bash
cd android && gradle wrapper --gradle-version 8.6 && cd ..
```

## Step 1 — install dependencies

```bash
cp .env.example .env
# edit .env: set API_BASE_URL to your backend, and GOOGLE_SERVER_CLIENT_ID /
# RAZORPAY_KEY_ID once you have them

flutter pub get
```

## Step 2 — Android build config (already done for you)

Nothing to configure manually — this is already wired:

- `android/app/build.gradle` — `applicationId com.lifeos.app`, minSdk 23,
  targetSdk/compileSdk 34, Kotlin 1.9.24, AGP 8.3.2, ProGuard rules for
  release, multidex enabled.
- `android/app/src/main/AndroidManifest.xml` — internet, notification,
  photo-picker permissions; Razorpay checkout activity registered; a
  network security config that allows cleartext **only** for
  `10.0.2.2`/`localhost` (emulator dev) and blocks it everywhere else.
- Real launcher icons generated at every mipmap density
  (`android/app/src/main/res/mipmap-*/ic_launcher.png`).

## Step 3 — generate a release APK

```bash
flutter build apk --release
```

Output: `build/app/outputs/flutter-apk/app-release.apk`

## Step 4 — signing (already configured, debug-keystore fallback)

A **real, valid debug keystore** is bundled at `android/app/debug.keystore`
(alias `androiddebugkey`, password `android` — the Android-standard debug
credentials). `android/app/build.gradle` signs release builds with it
automatically whenever `android/key.properties` is absent, so step 3 above
already produces a **signed, installable** APK with zero manual steps.

To switch to a real production keystore later (required before any Play
Store submission — Google does not accept debug-signed APKs), see
`android/key.properties.example` for the two-command process.

## Step 5 — install and test on a device/emulator

```bash
# with an emulator running or a device connected via `adb devices`
adb install build/app/outputs/flutter-apk/app-release.apk

# or let Flutter do both build + install + launch:
flutter install
```

## Step 6 — fixing build errors

If `flutter build apk --release` fails, it will be one of these known
categories — fixes below:

| Error mentions | Fix |
|---|---|
| `SDK location not found` | Create `android/local.properties` (see `android/local.properties.example`) with your `sdk.dir` and `flutter.sdk` paths |
| `Gradle wrapper` / `gradle-wrapper.jar` missing | See Step 0 |
| A specific plugin's `compileSdk`/Kotlin version mismatch | Run `flutter pub upgrade` — the versions pinned in `pubspec.yaml` were current as of this build but plugin authors do update minimums |
| Google Sign-In `DEVELOPER_ERROR` at runtime | Your app's SHA-1 fingerprint isn't registered in the Google Cloud Console OAuth client. Run `keytool -list -v -keystore android/app/debug.keystore -storepass android -alias androiddebugkey` to get the SHA-1, add it there |
| Razorpay checkout doesn't open | `RAZORPAY_KEY_ID` in `.env` is empty/wrong — must match the `key_id` your backend returns from `/subscriptions/checkout` |

## Why this wasn't built for you automatically

This code was generated inside a sandboxed container with:
- **No Flutter or Dart SDK installed** (`which flutter dart` → not found)
- **No network access at all** — every external host (pub.dev, Google's
  Flutter artifact storage, Gradle's distribution servers) returns
  `403 host_not_allowed`

That means `flutter pub get`, `flutter build apk`, and any install/launch
step were physically impossible to run in that environment — not a
choice, a hard constraint. What *was* possible and *was* done:

- Every `.dart` file was checked with an offline structural linter
  (`tools/dart_sanity_check.py`) verifying balanced braces and that every
  relative import resolves to a real file — 52/52 files pass.
- Every Riverpod provider referenced anywhere in the app was
  cross-checked against its definition — no dangling references.
- A **real, valid** debug keystore was generated with `keytool` (which
  needs no network) and wired into the release signing config.
- Real launcher icon PNGs were generated at all required densities.

None of this substitutes for `flutter analyze` or an actual build — please
run Step 1–3 on your machine and report back any error; it'll get fixed
immediately.
