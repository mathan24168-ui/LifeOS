import 'package:flutter/material.dart';

/// Centralized color palette for LifeOS AI's dark, premium visual identity.
class AppColors {
  AppColors._();

  // Backgrounds
  static const Color background = Color(0xFF0B0E14);
  static const Color surface = Color(0xFF141824);
  static const Color surfaceElevated = Color(0xFF1C2130);
  static const Color surfaceHighlight = Color(0xFF232A3D);

  // Brand / accent
  static const Color primary = Color(0xFF6C5CE7); // violet
  static const Color primaryLight = Color(0xFF8B7FF0);
  static const Color secondary = Color(0xFF00D9C0); // teal accent
  static const Color gold = Color(0xFFF5B942); // premium accent for paywall

  // Semantic
  static const Color success = Color(0xFF2ECC71);
  static const Color warning = Color(0xFFF5A623);
  static const Color danger = Color(0xFFE74C3C);
  static const Color info = Color(0xFF3498DB);

  // Text
  static const Color textPrimary = Color(0xFFF5F6FA);
  static const Color textSecondary = Color(0xFFA0A6B8);
  static const Color textMuted = Color(0xFF5C6378);

  // Borders / dividers
  static const Color border = Color(0xFF2A3040);

  // Priority colors (Tasks)
  static const Color priorityLow = Color(0xFF3498DB);
  static const Color priorityMedium = Color(0xFFF5A623);
  static const Color priorityHigh = Color(0xFFE67E22);
  static const Color priorityUrgent = Color(0xFFE74C3C);

  static const LinearGradient premiumGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF6C5CE7), Color(0xFF00D9C0)],
  );

  static const LinearGradient goldGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFF5B942), Color(0xFFE67E22)],
  );
}
