import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../network/api_client.dart';
import '../network/token_storage.dart';

/// Singleton token storage instance.
final tokenStorageProvider = Provider<TokenStorage>((ref) => TokenStorage());

/// Notifies listeners (primarily the router) that auth has expired and the
/// user must be redirected to login. Incremented as a simple change signal.
final authExpiredNotifierProvider = StateProvider<int>((ref) => 0);

/// Singleton API client wired with auth interceptors.
final apiClientProvider = Provider<ApiClient>((ref) {
  final tokenStorage = ref.watch(tokenStorageProvider);
  return ApiClient(
    tokenStorage: tokenStorage,
    onAuthExpired: () {
      ref.read(authExpiredNotifierProvider.notifier).state++;
    },
  );
});
