/// Central registry of route paths to avoid magic strings scattered
/// across the app.
class AppRoutes {
  AppRoutes._();

  static const String splash = '/splash';
  static const String login = '/login';
  static const String register = '/register';
  static const String paywall = '/paywall';

  static const String home = '/home';
  static const String dashboard = '/home/dashboard';
  static const String chat = '/home/chat';
  static const String chatConversation = '/home/chat/:conversationId';
  static const String notes = '/home/notes';
  static const String noteDetail = '/home/notes/:noteId';
  static const String tasks = '/home/tasks';
  static const String calendar = '/home/calendar';
  static const String search = '/home/search';
  static const String profile = '/home/profile';
}
