import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/providers/auth_notifier.dart';
import '../../features/auth/presentation/providers/auth_state.dart';
import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/auth/presentation/screens/register_screen.dart';
import '../../features/auth/presentation/screens/splash_screen.dart';
import '../../features/calendar/presentation/screens/calendar_screen.dart';
import '../../features/chat/presentation/screens/conversations_list_screen.dart';
import '../../features/dashboard/presentation/screens/dashboard_screen.dart';
import '../../features/notes/presentation/screens/notes_list_screen.dart';
import '../../features/paywall/presentation/screens/paywall_screen.dart';
import '../../features/profile/presentation/screens/profile_screen.dart';
import '../../features/search/presentation/screens/search_screen.dart';
import '../../features/tasks/presentation/screens/tasks_list_screen.dart';
import '../../shared/widgets/home_shell.dart';
import 'app_routes.dart';

final _rootNavigatorKey = GlobalKey<NavigatorState>();

/// Small wrapper so [GoRouter]'s `refreshListenable` can react to Riverpod
/// auth state changes without go_router needing to know about Riverpod.
class _AuthRefreshNotifier extends ChangeNotifier {
  _AuthRefreshNotifier(Ref ref) {
    ref.listen(authNotifierProvider, (previous, next) {
      if (previous?.status != next.status || previous?.needsSubscription != next.needsSubscription) {
        notifyListeners();
      }
    });
  }
}

final routerProvider = Provider<GoRouter>((ref) {
  final refreshNotifier = _AuthRefreshNotifier(ref);

  return GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: AppRoutes.splash,
    refreshListenable: refreshNotifier,
    redirect: (context, state) {
      final authState = ref.read(authNotifierProvider);
      final location = state.matchedLocation;

      final isSplash = location == AppRoutes.splash;
      final isAuthRoute = location == AppRoutes.login || location == AppRoutes.register;
      final isPaywall = location == AppRoutes.paywall;

      // Still bootstrapping (checking stored session) — stay on splash.
      if (authState.status == AuthStatus.unknown) {
        return isSplash ? null : AppRoutes.splash;
      }

      // Not logged in — force to login unless already on an auth screen.
      if (authState.status == AuthStatus.unauthenticated) {
        return isAuthRoute ? null : AppRoutes.login;
      }

      // Logged in but no active subscription — force to paywall.
      if (authState.needsSubscription) {
        return isPaywall ? null : AppRoutes.paywall;
      }

      // Logged in and subscribed — keep them out of splash/auth/paywall.
      if (isSplash || isAuthRoute || isPaywall) {
        return AppRoutes.dashboard;
      }

      return null;
    },
    routes: [
      GoRoute(path: AppRoutes.splash, builder: (context, state) => const SplashScreen()),
      GoRoute(path: AppRoutes.login, builder: (context, state) => const LoginScreen()),
      GoRoute(path: AppRoutes.register, builder: (context, state) => const RegisterScreen()),
      GoRoute(path: AppRoutes.paywall, builder: (context, state) => const PaywallScreen()),
      GoRoute(path: AppRoutes.profile, builder: (context, state) => const ProfileScreen()),
      GoRoute(path: AppRoutes.search, builder: (context, state) => const SearchScreen()),
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) => HomeShell(navigationShell: navigationShell),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(path: AppRoutes.dashboard, builder: (context, state) => const DashboardScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: AppRoutes.chat, builder: (context, state) => const ConversationsListScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: AppRoutes.notes, builder: (context, state) => const NotesListScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: AppRoutes.tasks, builder: (context, state) => const TasksListScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: AppRoutes.calendar, builder: (context, state) => const CalendarScreen()),
          ]),
        ],
      ),
    ],
  );
});
