import 'package:flutter_dotenv/flutter_dotenv.dart';

/// App-wide constants. Values that are secrets or environment-specific are
/// read from `.env` via [flutter_dotenv] in [EnvConfig], not hard-coded here.
class AppConstants {
  AppConstants._();

  static const String appName = 'LifeOS AI';

  // Subscription
  static const int subscriptionPriceInr = 249;
  static const String subscriptionLabel = '₹249/month';

  // Secure storage keys
  static const String accessTokenKey = 'lifeos_access_token';
  static const String refreshTokenKey = 'lifeos_refresh_token';

  // Pagination defaults
  static const int defaultPageSize = 20;

  // Timeouts
  static const Duration connectTimeout = Duration(seconds: 15);
  static const Duration receiveTimeout = Duration(seconds: 30);
  static const Duration aiReceiveTimeout = Duration(seconds: 60);
}

/// Reads environment configuration loaded via flutter_dotenv at app startup
/// (see `dotenv.load()` in main.dart, which must run before any of these
/// getters are accessed).
class EnvConfig {
  EnvConfig._();

  static String get apiBaseUrl =>
      dotenv.env['API_BASE_URL'] ?? 'http://10.0.2.2:8000/api/v1';

  static String get googleServerClientId => dotenv.env['GOOGLE_SERVER_CLIENT_ID'] ?? '';

  static String get razorpayKeyId => dotenv.env['RAZORPAY_KEY_ID'] ?? '';
}
