import 'package:dio/dio.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';

import '../constants/app_constants.dart';
import 'api_exception.dart';
import 'token_storage.dart';

/// Callback invoked when the refresh token itself is invalid/expired —
/// used by the app shell to force a logout + redirect to the login screen.
typedef OnAuthExpired = void Function();

/// Wraps a configured [Dio] instance with:
/// - automatic `Authorization: Bearer` header injection
/// - automatic access-token refresh on a single 401 retry
/// - normalized [ApiException] errors for the UI layer
class ApiClient {
  ApiClient({
    required TokenStorage tokenStorage,
    OnAuthExpired? onAuthExpired,
    Dio? dio,
  })  : _tokenStorage = tokenStorage,
        _onAuthExpired = onAuthExpired,
        _dio = dio ??
            Dio(
              BaseOptions(
                baseUrl: EnvConfig.apiBaseUrl,
                connectTimeout: AppConstants.connectTimeout,
                receiveTimeout: AppConstants.receiveTimeout,
                headers: {'Content-Type': 'application/json'},
              ),
            ) {
    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          final token = await _tokenStorage.getAccessToken();
          if (token != null) {
            options.headers['Authorization'] = 'Bearer $token';
          }
          handler.next(options);
        },
        onError: (DioException error, handler) async {
          if (error.response?.statusCode == 401 && !_isAuthEndpoint(error.requestOptions.path)) {
            final retried = await _tryRefreshAndRetry(error);
            if (retried != null) {
              return handler.resolve(retried);
            }
            _onAuthExpired?.call();
          }
          handler.next(error);
        },
      ),
    );

    _dio.interceptors.add(
      PrettyDioLogger(
        requestHeader: false,
        requestBody: true,
        responseBody: true,
        error: true,
        compact: true,
      ),
    );
  }

  final Dio _dio;
  final TokenStorage _tokenStorage;
  final OnAuthExpired? _onAuthExpired;

  bool _isRefreshing = false;

  bool _isAuthEndpoint(String path) =>
      path.contains('/auth/login') || path.contains('/auth/register') || path.contains('/auth/refresh');

  Future<Response<dynamic>?> _tryRefreshAndRetry(DioException error) async {
    if (_isRefreshing) return null;
    _isRefreshing = true;
    try {
      final refreshToken = await _tokenStorage.getRefreshToken();
      if (refreshToken == null) return null;

      final refreshDio = Dio(BaseOptions(baseUrl: EnvConfig.apiBaseUrl));
      final response = await refreshDio.post('/auth/refresh', data: {'refresh_token': refreshToken});

      final newAccess = response.data['access_token'] as String;
      final newRefresh = response.data['refresh_token'] as String;
      await _tokenStorage.saveTokens(accessToken: newAccess, refreshToken: newRefresh);

      final retriedRequest = error.requestOptions;
      retriedRequest.headers['Authorization'] = 'Bearer $newAccess';
      return await _dio.fetch(retriedRequest);
    } catch (_) {
      await _tokenStorage.clear();
      return null;
    } finally {
      _isRefreshing = false;
    }
  }

  Dio get raw => _dio;

  Future<Response<T>> get<T>(String path, {Map<String, dynamic>? queryParameters}) async {
    try {
      return await _dio.get<T>(path, queryParameters: queryParameters);
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  Future<Response<T>> post<T>(String path, {dynamic data}) async {
    try {
      return await _dio.post<T>(path, data: data);
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  Future<Response<T>> put<T>(String path, {dynamic data}) async {
    try {
      return await _dio.put<T>(path, data: data);
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  Future<Response<T>> patch<T>(String path, {dynamic data}) async {
    try {
      return await _dio.patch<T>(path, data: data);
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  Future<Response<T>> delete<T>(String path, {dynamic data}) async {
    try {
      return await _dio.delete<T>(path, data: data);
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  ApiException _mapError(DioException e) {
    final statusCode = e.response?.statusCode;
    String message;

    if (e.type == DioExceptionType.connectionTimeout ||
        e.type == DioExceptionType.receiveTimeout ||
        e.type == DioExceptionType.sendTimeout) {
      message = 'The connection timed out. Please check your internet and try again.';
    } else if (e.type == DioExceptionType.connectionError) {
      message = 'Could not connect to LifeOS AI. Please check your internet connection.';
    } else if (e.response?.data is Map && (e.response?.data as Map).containsKey('detail')) {
      final detail = (e.response!.data as Map)['detail'];
      message = detail is String ? detail : detail.toString();
    } else {
      message = 'Something went wrong. Please try again.';
    }

    return ApiException(message: message, statusCode: statusCode);
  }
}
