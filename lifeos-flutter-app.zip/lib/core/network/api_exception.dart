/// Normalized API error surfaced to the UI layer regardless of the
/// underlying transport failure (network, timeout, 4xx/5xx, parsing).
class ApiException implements Exception {
  ApiException({required this.message, this.statusCode});

  final String message;
  final int? statusCode;

  bool get isUnauthorized => statusCode == 401;
  bool get isSubscriptionRequired => statusCode == 402;
  bool get isForbidden => statusCode == 403;
  bool get isNotFound => statusCode == 404;
  bool get isRateLimited => statusCode == 429;

  @override
  String toString() => message;
}
