import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/router/app_routes.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../shared/widgets/primary_button.dart';
import '../../../auth/presentation/providers/auth_notifier.dart';
import '../providers/paywall_provider.dart';

class PaywallScreen extends ConsumerStatefulWidget {
  const PaywallScreen({super.key});

  @override
  ConsumerState<PaywallScreen> createState() => _PaywallScreenState();
}

class _PaywallScreenState extends ConsumerState<PaywallScreen> {
  late final Razorpay _razorpay;

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _onPaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _onPaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _onExternalWallet);
  }

  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }

  Future<void> _startSubscription() async {
    final session = await ref.read(paywallProvider.notifier).startCheckout();
    if (session == null || !mounted) return;

    final options = {
      'key': session.keyId,
      'subscription_id': session.subscriptionId,
      'name': AppConstants.appName,
      'description': 'Premium subscription — ${AppConstants.subscriptionLabel}',
      'prefill': {
        if (session.name != null) 'name': session.name,
        if (session.email != null) 'email': session.email,
      },
      'theme': {'color': '#6C5CE7'},
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      ref.read(paywallProvider.notifier).reportCheckoutFailure('Could not open payment screen: $e');
    }
  }

  void _onPaymentSuccess(PaymentSuccessResponse response) async {
    final ok = await ref.read(paywallProvider.notifier).verifyPayment(
          razorpayPaymentId: response.paymentId ?? '',
          razorpaySignature: response.signature ?? '',
        );
    if (!mounted) return;
    if (ok) {
      await ref.read(authNotifierProvider.notifier).refreshSubscriptionStatus();
      if (!mounted) return;
      context.go(AppRoutes.dashboard);
    }
  }

  void _onPaymentError(PaymentFailureResponse response) {
    ref.read(paywallProvider.notifier).reportCheckoutFailure(
          response.message ?? 'Payment failed. Please try again.',
        );
  }

  void _onExternalWallet(ExternalWalletResponse response) {
    // No-op: informational event from Razorpay when an external wallet is selected.
  }

  @override
  Widget build(BuildContext context) {
    final paywallState = ref.watch(paywallProvider);

    ref.listen(paywallProvider, (previous, next) {
      if (next.status == PaywallStatus.error && next.errorMessage != null) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(next.errorMessage!)));
      }
    });

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const Spacer(),
              Container(
                width: 84,
                height: 84,
                decoration: const BoxDecoration(gradient: AppColors.goldGradient, shape: BoxShape.circle),
                child: const Icon(Icons.workspace_premium_rounded, color: Colors.white, size: 44),
              ),
              const SizedBox(height: 24),
              const Text(
                'Unlock LifeOS AI Premium',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              const Text(
                'A Premium subscription is required to use LifeOS AI — AI Chat, '
                'Smart Notes, Tasks, Calendar, and AI Search, all in one place.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.textSecondary, fontSize: 14, height: 1.5),
              ),
              const SizedBox(height: 32),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.border),
                ),
                child: Column(
                  children: [
                    const _FeatureRow(icon: Icons.chat_bubble_outline_rounded, label: 'Unlimited AI Chat'),
                    const _FeatureRow(icon: Icons.note_alt_outlined, label: 'Smart Notes with AI summarize & rewrite'),
                    const _FeatureRow(icon: Icons.task_alt_rounded, label: 'Tasks, reminders & priorities'),
                    const _FeatureRow(icon: Icons.calendar_month_rounded, label: 'Calendar & daily planner'),
                    const _FeatureRow(icon: Icons.search_rounded, label: 'AI Search across everything'),
                    const Divider(height: 32),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          AppConstants.subscriptionLabel,
                          style: Theme.of(context)
                              .textTheme
                              .headlineSmall
                              ?.copyWith(fontWeight: FontWeight.bold, color: AppColors.gold),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Billed monthly. Cancel anytime.',
                      style: TextStyle(color: AppColors.textMuted, fontSize: 12),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              PrimaryButton(
                label: 'Subscribe Now',
                isLoading: paywallState.isBusy,
                onPressed: _startSubscription,
                gradient: AppColors.goldGradient,
                icon: Icons.lock_open_rounded,
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () => ref.read(authNotifierProvider.notifier).logout(),
                child: const Text('Log out', style: TextStyle(color: AppColors.textMuted)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FeatureRow extends StatelessWidget {
  const _FeatureRow({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.secondary),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: const TextStyle(fontSize: 14))),
        ],
      ),
    );
  }
}
