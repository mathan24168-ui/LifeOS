import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/network/api_exception.dart';
import '../../../../core/providers/core_providers.dart';
import '../../data/repositories/subscription_repository.dart';

final subscriptionRepositoryProvider = Provider<SubscriptionRepository>((ref) {
  return SubscriptionRepository(apiClient: ref.watch(apiClientProvider));
});

enum PaywallStatus { idle, creatingSession, awaitingPayment, verifying, success, error }

class PaywallState {
  const PaywallState({this.status = PaywallStatus.idle, this.errorMessage});

  final PaywallStatus status;
  final String? errorMessage;

  bool get isBusy =>
      status == PaywallStatus.creatingSession ||
      status == PaywallStatus.awaitingPayment ||
      status == PaywallStatus.verifying;

  PaywallState copyWith({PaywallStatus? status, String? errorMessage}) {
    return PaywallState(status: status ?? this.status, errorMessage: errorMessage);
  }
}

final paywallProvider = StateNotifierProvider.autoDispose<PaywallNotifier, PaywallState>((ref) {
  return PaywallNotifier(ref.watch(subscriptionRepositoryProvider));
});

class PaywallNotifier extends StateNotifier<PaywallState> {
  PaywallNotifier(this._repository) : super(const PaywallState());

  final SubscriptionRepository _repository;
  String? _pendingSubscriptionId;

  /// Step 1: ask the backend to create a Razorpay subscription. Returns the
  /// razorpay_subscription_id + key_id the UI needs to open Razorpay Checkout,
  /// or null on failure (error is set in state).
  Future<({String subscriptionId, String keyId, String? name, String? email})?> startCheckout() async {
    state = state.copyWith(status: PaywallStatus.creatingSession, errorMessage: null);
    try {
      final session = await _repository.createCheckoutSession();
      _pendingSubscriptionId = session.razorpaySubscriptionId;
      state = state.copyWith(status: PaywallStatus.awaitingPayment);
      return (
        subscriptionId: session.razorpaySubscriptionId,
        keyId: session.razorpayKeyId,
        name: session.customerName,
        email: session.customerEmail,
      );
    } on ApiException catch (e) {
      state = state.copyWith(status: PaywallStatus.error, errorMessage: e.message);
      return null;
    }
  }

  /// Step 2: called once Razorpay's native checkout returns a successful
  /// payment result, to verify the signature server-side and activate access.
  Future<bool> verifyPayment({
    required String razorpayPaymentId,
    required String razorpaySignature,
  }) async {
    if (_pendingSubscriptionId == null) {
      state = state.copyWith(status: PaywallStatus.error, errorMessage: 'No active checkout session.');
      return false;
    }
    state = state.copyWith(status: PaywallStatus.verifying);
    try {
      await _repository.verifyPayment(
        razorpayPaymentId: razorpayPaymentId,
        razorpaySubscriptionId: _pendingSubscriptionId!,
        razorpaySignature: razorpaySignature,
      );
      state = state.copyWith(status: PaywallStatus.success);
      return true;
    } on ApiException catch (e) {
      state = state.copyWith(status: PaywallStatus.error, errorMessage: e.message);
      return false;
    }
  }

  void reportCheckoutFailure(String message) {
    state = state.copyWith(status: PaywallStatus.error, errorMessage: message);
  }

  void reportCheckoutCancelled() {
    state = state.copyWith(status: PaywallStatus.idle);
  }
}
