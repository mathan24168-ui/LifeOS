/// Subscription status mirrored from the backend `SubscriptionStatus` enum.
enum SubscriptionStatus {
  created,
  authenticated,
  active,
  pending,
  halted,
  cancelled,
  completed,
  expired,
  none, // client-side sentinel: user has no subscription record yet
}

SubscriptionStatus subscriptionStatusFromString(String? value) {
  switch (value) {
    case 'created':
      return SubscriptionStatus.created;
    case 'authenticated':
      return SubscriptionStatus.authenticated;
    case 'active':
      return SubscriptionStatus.active;
    case 'pending':
      return SubscriptionStatus.pending;
    case 'halted':
      return SubscriptionStatus.halted;
    case 'cancelled':
      return SubscriptionStatus.cancelled;
    case 'completed':
      return SubscriptionStatus.completed;
    case 'expired':
      return SubscriptionStatus.expired;
    default:
      return SubscriptionStatus.none;
  }
}

class SubscriptionModel {
  const SubscriptionModel({
    required this.status,
    this.currentEnd,
    this.amountInr = 249,
  });

  final SubscriptionStatus status;
  final DateTime? currentEnd;
  final int amountInr;

  bool get isActive => status == SubscriptionStatus.active || status == SubscriptionStatus.authenticated;

  factory SubscriptionModel.fromJson(Map<String, dynamic> json) {
    return SubscriptionModel(
      status: subscriptionStatusFromString(json['status'] as String?),
      currentEnd: json['current_end'] != null ? DateTime.tryParse(json['current_end'] as String) : null,
      amountInr: json['amount_inr'] as int? ?? 249,
    );
  }
}

/// Response from POST /subscriptions/checkout — everything the client
/// needs to open the Razorpay checkout UI.
class CheckoutSessionModel {
  const CheckoutSessionModel({
    required this.razorpaySubscriptionId,
    required this.razorpayKeyId,
    this.customerName,
    this.customerEmail,
  });

  final String razorpaySubscriptionId;
  final String razorpayKeyId;
  final String? customerName;
  final String? customerEmail;

  factory CheckoutSessionModel.fromJson(Map<String, dynamic> json) {
    return CheckoutSessionModel(
      razorpaySubscriptionId: json['razorpay_subscription_id'] as String,
      razorpayKeyId: json['razorpay_key_id'] as String,
      customerName: json['customer_name'] as String?,
      customerEmail: json['customer_email'] as String?,
    );
  }
}
