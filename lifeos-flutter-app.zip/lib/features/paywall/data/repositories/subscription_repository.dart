import '../../../../core/network/api_client.dart';
import '../models/subscription_model.dart';

/// Talks to the backend's subscription endpoints (built in backend Phase 2:
/// POST /subscriptions/checkout, POST /subscriptions/verify,
/// GET /subscriptions/me, POST /subscriptions/cancel).
///
/// NOTE: this repository assumes that exact contract. If the backend's
/// route names differ, update the paths below — nothing else in the app
/// needs to change.
class SubscriptionRepository {
  SubscriptionRepository({required ApiClient apiClient}) : _api = apiClient;

  final ApiClient _api;

  /// Creates (or reuses) a Razorpay subscription server-side and returns
  /// what the client needs to launch Razorpay Checkout.
  Future<CheckoutSessionModel> createCheckoutSession() async {
    final response = await _api.post('/subscriptions/checkout');
    return CheckoutSessionModel.fromJson(response.data as Map<String, dynamic>);
  }

  /// Sends the payment/subscription IDs + signature returned by the Razorpay
  /// SDK to the backend for signature verification and status activation.
  Future<SubscriptionModel> verifyPayment({
    required String razorpayPaymentId,
    required String razorpaySubscriptionId,
    required String razorpaySignature,
  }) async {
    final response = await _api.post('/subscriptions/verify', data: {
      'razorpay_payment_id': razorpayPaymentId,
      'razorpay_subscription_id': razorpaySubscriptionId,
      'razorpay_signature': razorpaySignature,
    });
    return SubscriptionModel.fromJson(response.data as Map<String, dynamic>);
  }

  Future<SubscriptionModel> fetchCurrentSubscription() async {
    final response = await _api.get('/subscriptions/me');
    return SubscriptionModel.fromJson(response.data as Map<String, dynamic>);
  }

  Future<void> cancelSubscription() => _api.post('/subscriptions/cancel');
}
