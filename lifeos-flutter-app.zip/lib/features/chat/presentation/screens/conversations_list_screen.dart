import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:timeago/timeago.dart' as timeago;

import '../../../../core/theme/app_colors.dart';
import '../../../../shared/widgets/state_views.dart';
import '../providers/chat_provider.dart';
import 'chat_conversation_screen.dart';

class ConversationsListScreen extends ConsumerWidget {
  const ConversationsListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final conversationsAsync = ref.watch(conversationsListProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('AI Chat')),
      body: RefreshIndicator(
        onRefresh: () => ref.read(conversationsListProvider.notifier).refresh(),
        child: conversationsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (err, _) => ErrorStateView(
            message: err.toString(),
            onRetry: () => ref.read(conversationsListProvider.notifier).refresh(),
          ),
          data: (conversations) {
            if (conversations.isEmpty) {
              return EmptyStateView(
                icon: Icons.chat_bubble_outline_rounded,
                title: 'Start a conversation',
                subtitle: 'Ask LifeOS AI anything — plan your day, brainstorm, or get advice.',
                action: FilledButton.icon(
                  onPressed: () => _startNewChat(context, ref),
                  icon: const Icon(Icons.add_rounded),
                  label: const Text('New chat'),
                ),
              );
            }
            return ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: conversations.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final convo = conversations[index];
                return Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    leading: const CircleAvatar(
                      backgroundColor: AppColors.primary,
                      child: Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 18),
                    ),
                    title: Text(convo.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(timeago.format(convo.updatedAt), style: const TextStyle(fontSize: 12)),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline_rounded, size: 20),
                      onPressed: () => ref.read(conversationsListProvider.notifier).deleteConversation(convo.id),
                    ),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => ChatConversationScreen(conversationId: convo.id, title: convo.title),
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _startNewChat(context, ref),
        child: const Icon(Icons.add_rounded),
      ),
    );
  }

  Future<void> _startNewChat(BuildContext context, WidgetRef ref) async {
    final convo = await ref.read(conversationsListProvider.notifier).createConversation();
    if (!context.mounted) return;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ChatConversationScreen(conversationId: convo.id, title: convo.title),
      ),
    );
  }
}
