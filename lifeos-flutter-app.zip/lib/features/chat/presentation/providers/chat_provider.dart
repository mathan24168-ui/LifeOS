import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/network/api_exception.dart';
import '../../../../core/providers/core_providers.dart';
import '../../data/models/chat_models.dart';
import '../../data/repositories/chat_repository.dart';

final chatRepositoryProvider = Provider<ChatRepository>((ref) {
  return ChatRepository(apiClient: ref.watch(apiClientProvider));
});

final conversationsListProvider = AsyncNotifierProvider<ConversationsListNotifier, List<ConversationModel>>(
  ConversationsListNotifier.new,
);

class ConversationsListNotifier extends AsyncNotifier<List<ConversationModel>> {
  ChatRepository get _repo => ref.read(chatRepositoryProvider);

  @override
  Future<List<ConversationModel>> build() => _repo.fetchConversations();

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _repo.fetchConversations());
  }

  Future<ConversationModel> createConversation() async {
    final convo = await _repo.createConversation();
    state = AsyncData([convo, ...state.value ?? []]);
    return convo;
  }

  Future<void> deleteConversation(String id) async {
    await _repo.deleteConversation(id);
    state = AsyncData((state.value ?? []).where((c) => c.id != id).toList());
  }
}

/// Family provider: manages the message list + sending state for a single
/// open conversation.
final activeConversationProvider =
    AsyncNotifierProvider.family<ActiveConversationNotifier, ConversationModel, String>(
  ActiveConversationNotifier.new,
);

class ActiveConversationNotifier extends FamilyAsyncNotifier<ConversationModel, String> {
  ChatRepository get _repo => ref.read(chatRepositoryProvider);
  bool _isSending = false;
  late String _conversationId;

  bool get isSending => _isSending;

  @override
  Future<ConversationModel> build(String arg) {
    _conversationId = arg;
    return _repo.fetchConversation(arg);
  }

  Future<void> sendMessage(String content) async {
    if (content.trim().isEmpty || _isSending) return;
    final current = state.value;
    if (current == null) return;

    _isSending = true;

    // Optimistically append the user's message.
    final optimisticUserMsg = MessageModel(
      id: 'temp-${DateTime.now().microsecondsSinceEpoch}',
      role: MessageRole.user,
      content: content,
      createdAt: DateTime.now(),
    );
    state = AsyncData(ConversationModel(
      id: current.id,
      title: current.title,
      updatedAt: DateTime.now(),
      messages: [...current.messages, optimisticUserMsg],
    ));

    try {
      final assistantReply = await _repo.sendMessage(_conversationId, content);
      final latest = state.value ?? current;
      state = AsyncData(ConversationModel(
        id: latest.id,
        title: latest.title,
        updatedAt: DateTime.now(),
        messages: [...latest.messages, assistantReply],
      ));
    } on ApiException {
      // Roll back the optimistic message on failure so the UI doesn't lie
      // about what was actually persisted server-side.
      state = AsyncData(current);
      rethrow;
    } finally {
      _isSending = false;
    }
  }
}
