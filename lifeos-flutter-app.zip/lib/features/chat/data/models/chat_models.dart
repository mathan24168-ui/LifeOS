enum MessageRole { user, assistant, system }

MessageRole messageRoleFromString(String value) {
  switch (value) {
    case 'assistant':
      return MessageRole.assistant;
    case 'system':
      return MessageRole.system;
    default:
      return MessageRole.user;
  }
}

class MessageModel {
  const MessageModel({required this.id, required this.role, required this.content, required this.createdAt});

  final String id;
  final MessageRole role;
  final String content;
  final DateTime createdAt;

  factory MessageModel.fromJson(Map<String, dynamic> json) {
    return MessageModel(
      id: json['id'] as String,
      role: messageRoleFromString(json['role'] as String),
      content: json['content'] as String,
      createdAt: DateTime.tryParse(json['created_at'] as String? ?? '') ?? DateTime.now(),
    );
  }
}

class ConversationModel {
  const ConversationModel({
    required this.id,
    required this.title,
    required this.updatedAt,
    this.messages = const [],
  });

  final String id;
  final String title;
  final DateTime updatedAt;
  final List<MessageModel> messages;

  factory ConversationModel.fromJson(Map<String, dynamic> json) {
    return ConversationModel(
      id: json['id'] as String,
      title: json['title'] as String? ?? 'New Conversation',
      updatedAt: DateTime.tryParse(json['updated_at'] as String? ?? '') ?? DateTime.now(),
      messages: (json['messages'] as List?)
              ?.map((e) => MessageModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          const [],
    );
  }
}
