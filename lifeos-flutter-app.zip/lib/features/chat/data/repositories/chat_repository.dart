import '../../../../core/network/api_client.dart';
import '../models/chat_models.dart';

/// Talks to backend Chat endpoints (built in backend Phase 4):
/// GET /conversations, POST /conversations, GET /conversations/:id,
/// DELETE /conversations/:id, POST /conversations/:id/messages
class ChatRepository {
  ChatRepository({required ApiClient apiClient}) : _api = apiClient;

  final ApiClient _api;

  Future<List<ConversationModel>> fetchConversations() async {
    final response = await _api.get('/conversations');
    final list = response.data as List;
    return list.map((e) => ConversationModel.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<ConversationModel> fetchConversation(String id) async {
    final response = await _api.get('/conversations/$id');
    return ConversationModel.fromJson(response.data as Map<String, dynamic>);
  }

  Future<ConversationModel> createConversation() async {
    final response = await _api.post('/conversations');
    return ConversationModel.fromJson(response.data as Map<String, dynamic>);
  }

  Future<void> deleteConversation(String id) => _api.delete('/conversations/$id');

  /// Sends a user message and returns the assistant's reply message.
  /// The backend persists both the user message and the AI response.
  Future<MessageModel> sendMessage(String conversationId, String content) async {
    final response = await _api.post('/conversations/$conversationId/messages', data: {'content': content});
    return MessageModel.fromJson(response.data as Map<String, dynamic>);
  }
}
