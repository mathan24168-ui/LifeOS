import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:timeago/timeago.dart' as timeago;

import '../../../../core/theme/app_colors.dart';
import '../../../../shared/widgets/state_views.dart';
import '../../data/models/note_model.dart';
import '../providers/notes_provider.dart';
import 'note_editor_screen.dart';

class NotesListScreen extends ConsumerWidget {
  const NotesListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notesAsync = ref.watch(notesListProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Smart Notes')),
      body: RefreshIndicator(
        onRefresh: () => ref.read(notesListProvider.notifier).refresh(),
        child: notesAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (err, _) => ErrorStateView(
            message: err.toString(),
            onRetry: () => ref.read(notesListProvider.notifier).refresh(),
          ),
          data: (notes) {
            if (notes.isEmpty) {
              return const EmptyStateView(
                icon: Icons.note_add_outlined,
                title: 'No notes yet',
                subtitle: 'Tap + to create your first note. Use AI to summarize or rewrite it anytime.',
              );
            }
            final pinned = notes.where((n) => n.isPinned).toList();
            final others = notes.where((n) => !n.isPinned).toList();
            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (pinned.isNotEmpty) ...[
                  const _SectionLabel('Pinned'),
                  for (final note in pinned) _NoteCard(note: note),
                  const SizedBox(height: 12),
                ],
                if (others.isNotEmpty) ...[
                  const _SectionLabel('All notes'),
                  for (final note in others) _NoteCard(note: note),
                ],
              ],
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const NoteEditorScreen()),
        ),
        child: const Icon(Icons.add_rounded),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.label);
  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, top: 4),
      child: Text(
        label.toUpperCase(),
        style: const TextStyle(color: AppColors.textMuted, fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: 0.6),
      ),
    );
  }
}

class _NoteCard extends ConsumerWidget {
  const _NoteCard({required this.note});
  final NoteModel note;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => NoteEditorScreen(note: note)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      note.title.isEmpty ? 'Untitled note' : note.title,
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      note.isPinned ? Icons.push_pin_rounded : Icons.push_pin_outlined,
                      size: 18,
                      color: note.isPinned ? AppColors.gold : AppColors.textMuted,
                    ),
                    onPressed: () => ref.read(notesListProvider.notifier).togglePin(note.id, !note.isPinned),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                note.aiSummary ?? note.content,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.textSecondary, fontSize: 13, height: 1.4),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  if (note.aiSummary != null) ...[
                    const Icon(Icons.auto_awesome_rounded, size: 13, color: AppColors.secondary),
                    const SizedBox(width: 4),
                    const Text('AI summary', style: TextStyle(color: AppColors.secondary, fontSize: 11)),
                    const SizedBox(width: 10),
                  ],
                  Text(
                    timeago.format(note.updatedAt),
                    style: const TextStyle(color: AppColors.textMuted, fontSize: 11),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
