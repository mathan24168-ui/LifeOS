import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/providers/core_providers.dart';
import '../../data/models/note_model.dart';
import '../../data/repositories/notes_repository.dart';

final notesRepositoryProvider = Provider<NotesRepository>((ref) {
  return NotesRepository(apiClient: ref.watch(apiClientProvider));
});

final notesListProvider = AsyncNotifierProvider<NotesListNotifier, List<NoteModel>>(
  NotesListNotifier.new,
);

class NotesListNotifier extends AsyncNotifier<List<NoteModel>> {
  NotesRepository get _repo => ref.read(notesRepositoryProvider);

  @override
  Future<List<NoteModel>> build() => _repo.fetchNotes();

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _repo.fetchNotes());
  }

  Future<NoteModel> createNote({required String title, required String content}) async {
    final note = await _repo.createNote(title: title, content: content);
    state = AsyncData([note, ...state.value ?? []]);
    return note;
  }

  Future<void> updateNote(String id, {String? title, String? content}) async {
    final updated = await _repo.updateNote(id, title: title, content: content);
    _replaceNote(updated);
  }

  Future<void> deleteNote(String id) async {
    await _repo.deleteNote(id);
    state = AsyncData((state.value ?? []).where((n) => n.id != id).toList());
  }

  Future<void> togglePin(String id, bool pinned) async {
    final updated = await _repo.togglePin(id, pinned);
    _replaceNote(updated);
  }

  Future<NoteModel> summarize(String id) async {
    final updated = await _repo.summarize(id);
    _replaceNote(updated);
    return updated;
  }

  Future<NoteModel> rewrite(String id, {required String instruction}) async {
    final updated = await _repo.rewrite(id, instruction: instruction);
    _replaceNote(updated);
    return updated;
  }

  void _replaceNote(NoteModel updated) {
    final current = state.value ?? [];
    state = AsyncData([
      for (final n in current) if (n.id == updated.id) updated else n,
    ]);
  }
}
