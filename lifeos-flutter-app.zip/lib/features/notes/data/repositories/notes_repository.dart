import '../../../../core/network/api_client.dart';
import '../models/note_model.dart';

/// Talks to backend Notes endpoints (built in backend Phase 3):
/// GET/POST /notes, GET/PUT/DELETE /notes/:id,
/// POST /notes/:id/summarize, POST /notes/:id/rewrite
class NotesRepository {
  NotesRepository({required ApiClient apiClient}) : _api = apiClient;

  final ApiClient _api;

  Future<List<NoteModel>> fetchNotes({bool includeArchived = false}) async {
    final response = await _api.get('/notes', queryParameters: {'include_archived': includeArchived});
    final list = response.data as List;
    return list.map((e) => NoteModel.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<NoteModel> createNote({required String title, required String content}) async {
    final response = await _api.post('/notes', data: {'title': title, 'content': content});
    return NoteModel.fromJson(response.data as Map<String, dynamic>);
  }

  Future<NoteModel> updateNote(String id, {String? title, String? content}) async {
    final response = await _api.put('/notes/$id', data: {
      if (title != null) 'title': title,
      if (content != null) 'content': content,
    });
    return NoteModel.fromJson(response.data as Map<String, dynamic>);
  }

  Future<void> deleteNote(String id) => _api.delete('/notes/$id');

  Future<NoteModel> togglePin(String id, bool pinned) async {
    final response = await _api.patch('/notes/$id', data: {'is_pinned': pinned});
    return NoteModel.fromJson(response.data as Map<String, dynamic>);
  }

  /// Uses the AI layer (provider-agnostic on the backend) to summarize the
  /// note's content. Returns the updated note with `ai_summary` populated.
  Future<NoteModel> summarize(String id) async {
    final response = await _api.post('/notes/$id/summarize');
    return NoteModel.fromJson(response.data as Map<String, dynamic>);
  }

  /// Uses AI to rewrite the note content in a requested style/tone.
  Future<NoteModel> rewrite(String id, {required String instruction}) async {
    final response = await _api.post('/notes/$id/rewrite', data: {'instruction': instruction});
    return NoteModel.fromJson(response.data as Map<String, dynamic>);
  }
}
