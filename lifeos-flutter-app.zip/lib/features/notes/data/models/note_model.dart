class NoteModel {
  const NoteModel({
    required this.id,
    required this.title,
    required this.content,
    this.aiSummary,
    this.tags = const [],
    this.isPinned = false,
    this.isArchived = false,
    required this.updatedAt,
  });

  final String id;
  final String title;
  final String content;
  final String? aiSummary;
  final List<String> tags;
  final bool isPinned;
  final bool isArchived;
  final DateTime updatedAt;

  factory NoteModel.fromJson(Map<String, dynamic> json) {
    return NoteModel(
      id: json['id'] as String,
      title: json['title'] as String,
      content: json['content'] as String? ?? '',
      aiSummary: json['ai_summary'] as String?,
      tags: (json['tags'] as List?)?.map((e) => e.toString()).toList() ?? const [],
      isPinned: json['is_pinned'] as bool? ?? false,
      isArchived: json['is_archived'] as bool? ?? false,
      updatedAt: DateTime.tryParse(json['updated_at'] as String? ?? '') ?? DateTime.now(),
    );
  }

  NoteModel copyWith({
    String? title,
    String? content,
    String? aiSummary,
    bool? isPinned,
    bool? isArchived,
  }) {
    return NoteModel(
      id: id,
      title: title ?? this.title,
      content: content ?? this.content,
      aiSummary: aiSummary ?? this.aiSummary,
      tags: tags,
      isPinned: isPinned ?? this.isPinned,
      isArchived: isArchived ?? this.isArchived,
      updatedAt: DateTime.now(),
    );
  }
}
