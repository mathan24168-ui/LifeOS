import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/providers/core_providers.dart';
import '../../data/models/task_model.dart';
import '../../data/repositories/tasks_repository.dart';

final tasksRepositoryProvider = Provider<TasksRepository>((ref) {
  return TasksRepository(apiClient: ref.watch(apiClientProvider));
});

final tasksListProvider = AsyncNotifierProvider<TasksListNotifier, List<TaskModel>>(
  TasksListNotifier.new,
);

class TasksListNotifier extends AsyncNotifier<List<TaskModel>> {
  TasksRepository get _repo => ref.read(tasksRepositoryProvider);

  @override
  Future<List<TaskModel>> build() => _repo.fetchTasks();

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _repo.fetchTasks());
  }

  Future<void> createTask({
    required String title,
    String? description,
    required TaskPriority priority,
    DateTime? dueDate,
    DateTime? reminderAt,
  }) async {
    final task = await _repo.createTask(
      title: title,
      description: description,
      priority: priority,
      dueDate: dueDate,
      reminderAt: reminderAt,
    );
    state = AsyncData([task, ...state.value ?? []]);
  }

  Future<void> toggleComplete(String id, bool completed) async {
    final updated = await _repo.toggleComplete(id, completed);
    final current = state.value ?? [];
    state = AsyncData([for (final t in current) if (t.id == updated.id) updated else t]);
  }

  Future<void> deleteTask(String id) async {
    await _repo.deleteTask(id);
    state = AsyncData((state.value ?? []).where((t) => t.id != id).toList());
  }
}

/// Derived view: incomplete tasks due today, sorted by priority.
final todayTasksProvider = Provider<List<TaskModel>>((ref) {
  final tasks = ref.watch(tasksListProvider).value ?? [];
  final now = DateTime.now();
  final today = tasks.where((t) {
    if (t.isCompleted || t.dueDate == null) return false;
    final d = t.dueDate!;
    return d.year == now.year && d.month == now.month && d.day == now.day;
  }).toList();
  today.sort((a, b) => b.priority.index.compareTo(a.priority.index));
  return today;
});
