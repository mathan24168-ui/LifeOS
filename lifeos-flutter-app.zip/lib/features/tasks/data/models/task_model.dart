import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';

enum TaskPriority { low, medium, high, urgent }

TaskPriority taskPriorityFromString(String? value) {
  switch (value) {
    case 'low':
      return TaskPriority.low;
    case 'high':
      return TaskPriority.high;
    case 'urgent':
      return TaskPriority.urgent;
    default:
      return TaskPriority.medium;
  }
}

extension TaskPriorityX on TaskPriority {
  String get apiValue => name;

  String get label {
    switch (this) {
      case TaskPriority.low:
        return 'Low';
      case TaskPriority.medium:
        return 'Medium';
      case TaskPriority.high:
        return 'High';
      case TaskPriority.urgent:
        return 'Urgent';
    }
  }

  Color get color {
    switch (this) {
      case TaskPriority.low:
        return AppColors.priorityLow;
      case TaskPriority.medium:
        return AppColors.priorityMedium;
      case TaskPriority.high:
        return AppColors.priorityHigh;
      case TaskPriority.urgent:
        return AppColors.priorityUrgent;
    }
  }
}

class TaskModel {
  const TaskModel({
    required this.id,
    required this.title,
    this.description,
    this.priority = TaskPriority.medium,
    this.dueDate,
    this.reminderAt,
    this.isCompleted = false,
  });

  final String id;
  final String title;
  final String? description;
  final TaskPriority priority;
  final DateTime? dueDate;
  final DateTime? reminderAt;
  final bool isCompleted;

  factory TaskModel.fromJson(Map<String, dynamic> json) {
    return TaskModel(
      id: json['id'] as String,
      title: json['title'] as String,
      description: json['description'] as String?,
      priority: taskPriorityFromString(json['priority'] as String?),
      dueDate: json['due_date'] != null ? DateTime.tryParse(json['due_date'] as String) : null,
      reminderAt: json['reminder_at'] != null ? DateTime.tryParse(json['reminder_at'] as String) : null,
      isCompleted: json['is_completed'] as bool? ?? false,
    );
  }

  TaskModel copyWith({bool? isCompleted}) {
    return TaskModel(
      id: id,
      title: title,
      description: description,
      priority: priority,
      dueDate: dueDate,
      reminderAt: reminderAt,
      isCompleted: isCompleted ?? this.isCompleted,
    );
  }
}
