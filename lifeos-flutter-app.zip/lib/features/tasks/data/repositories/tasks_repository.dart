import '../../../../core/network/api_client.dart';
import '../models/task_model.dart';

/// Talks to backend Tasks endpoints (built in backend Phase 3):
/// GET/POST /tasks, PUT/DELETE /tasks/:id, PATCH /tasks/:id/complete
class TasksRepository {
  TasksRepository({required ApiClient apiClient}) : _api = apiClient;

  final ApiClient _api;

  Future<List<TaskModel>> fetchTasks({bool? completed}) async {
    final response = await _api.get('/tasks', queryParameters: {
      if (completed != null) 'completed': completed,
    });
    final list = response.data as List;
    return list.map((e) => TaskModel.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<TaskModel> createTask({
    required String title,
    String? description,
    required TaskPriority priority,
    DateTime? dueDate,
    DateTime? reminderAt,
  }) async {
    final response = await _api.post('/tasks', data: {
      'title': title,
      if (description != null && description.isNotEmpty) 'description': description,
      'priority': priority.apiValue,
      if (dueDate != null) 'due_date': dueDate.toIso8601String(),
      if (reminderAt != null) 'reminder_at': reminderAt.toIso8601String(),
    });
    return TaskModel.fromJson(response.data as Map<String, dynamic>);
  }

  Future<TaskModel> toggleComplete(String id, bool completed) async {
    final response = await _api.patch('/tasks/$id', data: {'is_completed': completed});
    return TaskModel.fromJson(response.data as Map<String, dynamic>);
  }

  Future<void> deleteTask(String id) => _api.delete('/tasks/$id');
}
