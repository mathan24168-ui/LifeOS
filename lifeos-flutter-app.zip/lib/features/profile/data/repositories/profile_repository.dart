import 'dart:io';

import 'package:dio/dio.dart';

import '../../../../core/network/api_client.dart';
import '../../../auth/data/models/user_model.dart';

/// Talks to backend Profile endpoints (built in backend Phase 5):
/// PUT /users/me, POST /users/me/photo
class ProfileRepository {
  ProfileRepository({required ApiClient apiClient}) : _api = apiClient;

  final ApiClient _api;

  Future<UserModel> updateProfile({String? fullName}) async {
    final response = await _api.put('/users/me', data: {
      if (fullName != null) 'full_name': fullName,
    });
    return UserModel.fromJson(response.data as Map<String, dynamic>);
  }

  /// Uploads a profile photo as multipart/form-data. Uses the raw Dio
  /// instance directly since [ApiClient]'s typed wrapper methods assume
  /// JSON bodies; the Authorization header is still injected by the shared
  /// interceptor configured on that same Dio instance.
  Future<UserModel> uploadPhoto(File imageFile) async {
    final fileName = imageFile.path.split(Platform.pathSeparator).last;
    final formData = FormData.fromMap({
      'file': await MultipartFile.fromFile(imageFile.path, filename: fileName),
    });
    final response = await _api.raw.post('/users/me/photo', data: formData);
    return UserModel.fromJson(response.data as Map<String, dynamic>);
  }
}
