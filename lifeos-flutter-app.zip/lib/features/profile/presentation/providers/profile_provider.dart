import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/providers/core_providers.dart';
import '../../../auth/presentation/providers/auth_notifier.dart';
import '../../data/repositories/profile_repository.dart';

final profileRepositoryProvider = Provider<ProfileRepository>((ref) {
  return ProfileRepository(apiClient: ref.watch(apiClientProvider));
});

final profileActionsProvider = Provider<ProfileActions>((ref) {
  return ProfileActions(ref);
});

/// Thin action wrapper that mutates the profile then refreshes the shared
/// [authNotifierProvider] state so the whole app sees the updated user.
class ProfileActions {
  ProfileActions(this._ref);
  final Ref _ref;

  ProfileRepository get _repo => _ref.read(profileRepositoryProvider);

  Future<void> updateName(String fullName) async {
    await _repo.updateProfile(fullName: fullName);
    await _ref.read(authNotifierProvider.notifier).refreshCurrentUser();
  }

  Future<void> uploadPhoto(File file) async {
    await _repo.uploadPhoto(file);
    await _ref.read(authNotifierProvider.notifier).refreshCurrentUser();
  }
}
