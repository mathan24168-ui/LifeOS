import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/router/app_routes.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../shared/widgets/state_views.dart';
import '../../../auth/presentation/providers/auth_notifier.dart';
import '../providers/dashboard_provider.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  String _greeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dashboardAsync = ref.watch(dashboardProvider);
    final user = ref.watch(authNotifierProvider).user;

    return Scaffold(
      appBar: AppBar(
        title: Text('${_greeting()}${user?.fullName?.isNotEmpty == true ? ', ${user!.fullName!.split(' ').first}' : ''}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_outline_rounded),
            onPressed: () => context.push(AppRoutes.profile),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async => ref.invalidate(dashboardProvider),
        child: dashboardAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (err, _) => ErrorStateView(
            message: err.toString(),
            onRetry: () => ref.invalidate(dashboardProvider),
          ),
          data: (dashboard) => ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _DashboardSection(
                title: "Today's Tasks",
                icon: Icons.task_alt_rounded,
                onSeeAll: () => context.go(AppRoutes.tasks),
                child: dashboard.todayTasks.isEmpty
                    ? const _InlineEmpty('No tasks due today')
                    : Column(
                        children: [
                          for (final task in dashboard.todayTasks.take(4))
                            ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: Icon(
                                task.isCompleted ? Icons.check_circle_rounded : Icons.circle_outlined,
                                color: task.isCompleted ? AppColors.success : task.priority.color,
                                size: 20,
                              ),
                              title: Text(
                                task.title,
                                style: TextStyle(
                                  decoration: task.isCompleted ? TextDecoration.lineThrough : null,
                                  fontSize: 14,
                                ),
                              ),
                              dense: true,
                            ),
                        ],
                      ),
              ),
              const SizedBox(height: 20),
              _DashboardSection(
                title: "Today's Notes",
                icon: Icons.note_alt_rounded,
                onSeeAll: () => context.go(AppRoutes.notes),
                child: dashboard.todayNotes.isEmpty
                    ? const _InlineEmpty('No notes created today')
                    : Column(
                        children: [
                          for (final note in dashboard.todayNotes.take(3))
                            ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: const Icon(Icons.description_outlined, size: 20, color: AppColors.secondary),
                              title: Text(note.title, style: const TextStyle(fontSize: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
                              dense: true,
                            ),
                        ],
                      ),
              ),
              const SizedBox(height: 20),
              _DashboardSection(
                title: 'Upcoming Events',
                icon: Icons.calendar_month_rounded,
                onSeeAll: () => context.go(AppRoutes.calendar),
                child: dashboard.upcomingEvents.isEmpty
                    ? const _InlineEmpty('Nothing scheduled')
                    : Column(
                        children: [
                          for (final event in dashboard.upcomingEvents.take(3))
                            ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: const Icon(Icons.event_rounded, size: 20, color: AppColors.primary),
                              title: Text(event.title, style: const TextStyle(fontSize: 14)),
                              subtitle: Text(
                                DateFormat('MMM d, h:mm a').format(event.startTime),
                                style: const TextStyle(fontSize: 12),
                              ),
                              dense: true,
                            ),
                        ],
                      ),
              ),
              const SizedBox(height: 20),
              _DashboardSection(
                title: 'Recent Chats',
                icon: Icons.chat_bubble_rounded,
                onSeeAll: () => context.go(AppRoutes.chat),
                child: dashboard.recentConversations.isEmpty
                    ? const _InlineEmpty('No conversations yet')
                    : Column(
                        children: [
                          for (final convo in dashboard.recentConversations.take(3))
                            ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: const Icon(Icons.auto_awesome_rounded, size: 20, color: AppColors.gold),
                              title: Text(convo.title, style: const TextStyle(fontSize: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
                              dense: true,
                            ),
                        ],
                      ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}

class _DashboardSection extends StatelessWidget {
  const _DashboardSection({
    required this.title,
    required this.icon,
    required this.child,
    required this.onSeeAll,
  });

  final String title;
  final IconData icon;
  final Widget child;
  final VoidCallback onSeeAll;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: AppColors.primaryLight),
              const SizedBox(width: 8),
              Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15))),
              TextButton(onPressed: onSeeAll, child: const Text('See all', style: TextStyle(fontSize: 12))),
            ],
          ),
          const Divider(height: 16),
          child,
        ],
      ),
    );
  }
}

class _InlineEmpty extends StatelessWidget {
  const _InlineEmpty(this.label);
  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(label, style: const TextStyle(color: AppColors.textMuted, fontSize: 13)),
    );
  }
}
