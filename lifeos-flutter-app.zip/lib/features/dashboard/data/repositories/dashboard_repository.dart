import '../../../../core/network/api_client.dart';
import '../../../calendar/data/models/event_model.dart';
import '../../../chat/data/models/chat_models.dart';
import '../../../notes/data/models/note_model.dart';
import '../../../tasks/data/models/task_model.dart';

/// Aggregated dashboard payload returned by the backend's single
/// GET /dashboard endpoint (built in backend Phase 5), which bundles
/// today's tasks/notes, upcoming events, and recent chats in one call
/// to avoid four separate round trips on app open.
class DashboardModel {
  const DashboardModel({
    required this.todayTasks,
    required this.todayNotes,
    required this.upcomingEvents,
    required this.recentConversations,
  });

  final List<TaskModel> todayTasks;
  final List<NoteModel> todayNotes;
  final List<EventModel> upcomingEvents;
  final List<ConversationModel> recentConversations;

  factory DashboardModel.fromJson(Map<String, dynamic> json) {
    return DashboardModel(
      todayTasks: (json['today_tasks'] as List? ?? [])
          .map((e) => TaskModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      todayNotes: (json['today_notes'] as List? ?? [])
          .map((e) => NoteModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      upcomingEvents: (json['upcoming_events'] as List? ?? [])
          .map((e) => EventModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      recentConversations: (json['recent_conversations'] as List? ?? [])
          .map((e) => ConversationModel.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}

class DashboardRepository {
  DashboardRepository({required ApiClient apiClient}) : _api = apiClient;

  final ApiClient _api;

  Future<DashboardModel> fetchDashboard() async {
    final response = await _api.get('/dashboard');
    return DashboardModel.fromJson(response.data as Map<String, dynamic>);
  }
}
