import '../../../../core/network/api_client.dart';
import '../../../../core/network/token_storage.dart';
import '../models/user_model.dart';

/// Handles all authentication API calls: register, login, Google login,
/// token refresh, and fetching the current user.
class AuthRepository {
  AuthRepository({required ApiClient apiClient, required TokenStorage tokenStorage})
      : _api = apiClient,
        _tokenStorage = tokenStorage;

  final ApiClient _api;
  final TokenStorage _tokenStorage;

  Future<void> register({required String email, required String password, String? fullName}) async {
    final response = await _api.post('/auth/register', data: {
      'email': email,
      'password': password,
      if (fullName != null && fullName.isNotEmpty) 'full_name': fullName,
    });
    await _persistTokens(response.data);
  }

  Future<void> login({required String email, required String password}) async {
    final response = await _api.post('/auth/login', data: {'email': email, 'password': password});
    await _persistTokens(response.data);
  }

  Future<void> loginWithGoogle({required String idToken}) async {
    final response = await _api.post('/auth/google', data: {'id_token': idToken});
    await _persistTokens(response.data);
  }

  Future<UserModel> fetchCurrentUser() async {
    final response = await _api.get('/auth/me');
    return UserModel.fromJson(response.data as Map<String, dynamic>);
  }

  Future<void> logout() => _tokenStorage.clear();

  Future<bool> hasStoredSession() async {
    final token = await _tokenStorage.getAccessToken();
    return token != null;
  }

  Future<void> _persistTokens(dynamic data) async {
    final map = data as Map<String, dynamic>;
    await _tokenStorage.saveTokens(
      accessToken: map['access_token'] as String,
      refreshToken: map['refresh_token'] as String,
    );
  }
}
