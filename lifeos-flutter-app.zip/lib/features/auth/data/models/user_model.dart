/// User profile model, mirrors the backend's UserRead schema.
class UserModel {
  const UserModel({
    required this.id,
    required this.email,
    this.fullName,
    this.photoUrl,
    required this.role,
    required this.isActive,
    required this.isVerified,
    required this.hasActiveSubscription,
  });

  final String id;
  final String email;
  final String? fullName;
  final String? photoUrl;
  final String role;
  final bool isActive;
  final bool isVerified;
  final bool hasActiveSubscription;

  bool get isAdmin => role == 'admin';

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] as String,
      email: json['email'] as String,
      fullName: json['full_name'] as String?,
      photoUrl: json['photo_url'] as String?,
      role: json['role'] as String? ?? 'user',
      isActive: json['is_active'] as bool? ?? true,
      isVerified: json['is_verified'] as bool? ?? false,
      hasActiveSubscription: json['has_active_subscription'] as bool? ?? false,
    );
  }

  UserModel copyWith({
    String? fullName,
    String? photoUrl,
    bool? hasActiveSubscription,
  }) {
    return UserModel(
      id: id,
      email: email,
      fullName: fullName ?? this.fullName,
      photoUrl: photoUrl ?? this.photoUrl,
      role: role,
      isActive: isActive,
      isVerified: isVerified,
      hasActiveSubscription: hasActiveSubscription ?? this.hasActiveSubscription,
    );
  }
}
