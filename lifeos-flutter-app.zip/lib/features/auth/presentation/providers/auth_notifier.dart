import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/network/api_exception.dart';
import '../../../../core/providers/core_providers.dart';
import '../../data/repositories/auth_repository.dart';
import 'auth_state.dart';

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return AuthRepository(
    apiClient: ref.watch(apiClientProvider),
    tokenStorage: ref.watch(tokenStorageProvider),
  );
});

final authNotifierProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  final notifier = AuthNotifier(ref.watch(authRepositoryProvider));
  // React to forced logout signaled by the API client on refresh failure.
  ref.listen(authExpiredNotifierProvider, (previous, next) {
    if (previous != next) {
      notifier.logout();
    }
  });
  return notifier;
});

class AuthNotifier extends StateNotifier<AuthState> {
  AuthNotifier(this._repository) : super(const AuthState.unknown()) {
    bootstrap();
  }

  final AuthRepository _repository;
  final GoogleSignIn _googleSignIn = GoogleSignIn(
    serverClientId: EnvConfig.googleServerClientId.isNotEmpty ? EnvConfig.googleServerClientId : null,
    scopes: ['email', 'profile'],
  );

  Future<void> bootstrap() async {
    final hasSession = await _repository.hasStoredSession();
    if (!hasSession) {
      state = const AuthState(status: AuthStatus.unauthenticated);
      return;
    }
    await refreshCurrentUser();
  }

  Future<void> refreshCurrentUser() async {
    try {
      final user = await _repository.fetchCurrentUser();
      state = AuthState(status: AuthStatus.authenticated, user: user);
    } on ApiException {
      state = const AuthState(status: AuthStatus.unauthenticated);
    }
  }

  Future<bool> register({required String email, required String password, String? fullName}) async {
    try {
      await _repository.register(email: email, password: password, fullName: fullName);
      await refreshCurrentUser();
      return true;
    } on ApiException catch (e) {
      state = AuthState(status: AuthStatus.unauthenticated, errorMessage: e.message);
      return false;
    }
  }

  Future<bool> login({required String email, required String password}) async {
    try {
      await _repository.login(email: email, password: password);
      await refreshCurrentUser();
      return true;
    } on ApiException catch (e) {
      state = AuthState(status: AuthStatus.unauthenticated, errorMessage: e.message);
      return false;
    }
  }

  Future<bool> loginWithGoogle() async {
    try {
      final account = await _googleSignIn.signIn();
      if (account == null) return false; // user cancelled

      final authTokens = await account.authentication;
      final idToken = authTokens.idToken;
      if (idToken == null) {
        state = const AuthState(
          status: AuthStatus.unauthenticated,
          errorMessage: 'Google sign-in did not return a valid token. Please try again.',
        );
        return false;
      }

      await _repository.loginWithGoogle(idToken: idToken);
      await refreshCurrentUser();
      return true;
    } on ApiException catch (e) {
      state = AuthState(status: AuthStatus.unauthenticated, errorMessage: e.message);
      return false;
    } catch (_) {
      state = const AuthState(
        status: AuthStatus.unauthenticated,
        errorMessage: 'Google sign-in failed. Please try again.',
      );
      return false;
    }
  }

  /// Called after a successful subscription purchase to refresh gating state
  /// without requiring the user to log out/in.
  Future<void> refreshSubscriptionStatus() => refreshCurrentUser();

  Future<void> logout() async {
    await _repository.logout();
    try {
      await _googleSignIn.signOut();
    } catch (_) {
      // best-effort; local session clear already happened
    }
    state = const AuthState(status: AuthStatus.unauthenticated);
  }
}
