import '../../data/models/user_model.dart';

enum AuthStatus { unknown, authenticated, unauthenticated }

/// Immutable auth state consumed by the router and UI to decide what to show.
class AuthState {
  const AuthState({required this.status, this.user, this.errorMessage});

  const AuthState.unknown() : this(status: AuthStatus.unknown);

  final AuthStatus status;
  final UserModel? user;
  final String? errorMessage;

  bool get isAuthenticated => status == AuthStatus.authenticated && user != null;
  bool get needsSubscription => isAuthenticated && !(user!.hasActiveSubscription || user!.isAdmin);

  AuthState copyWith({AuthStatus? status, UserModel? user, String? errorMessage}) {
    return AuthState(
      status: status ?? this.status,
      user: user ?? this.user,
      errorMessage: errorMessage,
    );
  }
}
