import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/providers/core_providers.dart';
import '../../data/models/event_model.dart';
import '../../data/repositories/events_repository.dart';

final eventsRepositoryProvider = Provider<EventsRepository>((ref) {
  return EventsRepository(apiClient: ref.watch(apiClientProvider));
});

final eventsListProvider = AsyncNotifierProvider<EventsListNotifier, List<EventModel>>(
  EventsListNotifier.new,
);

class EventsListNotifier extends AsyncNotifier<List<EventModel>> {
  EventsRepository get _repo => ref.read(eventsRepositoryProvider);

  @override
  Future<List<EventModel>> build() {
    final now = DateTime.now();
    return _repo.fetchEvents(
      from: DateTime(now.year, now.month - 1, 1),
      to: DateTime(now.year, now.month + 2, 0),
    );
  }

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(build);
  }

  Future<void> createEvent({
    required String title,
    String? description,
    String? location,
    required DateTime startTime,
    required DateTime endTime,
    bool allDay = false,
  }) async {
    final event = await _repo.createEvent(
      title: title,
      description: description,
      location: location,
      startTime: startTime,
      endTime: endTime,
      allDay: allDay,
    );
    state = AsyncData([...state.value ?? [], event]);
  }

  Future<void> deleteEvent(String id) async {
    await _repo.deleteEvent(id);
    state = AsyncData((state.value ?? []).where((e) => e.id != id).toList());
  }
}

/// Events happening today, sorted by start time — used by Dashboard too.
final upcomingEventsProvider = Provider<List<EventModel>>((ref) {
  final events = ref.watch(eventsListProvider).value ?? [];
  final now = DateTime.now();
  final upcoming = events.where((e) => e.endTime.isAfter(now)).toList()
    ..sort((a, b) => a.startTime.compareTo(b.startTime));
  return upcoming;
});
