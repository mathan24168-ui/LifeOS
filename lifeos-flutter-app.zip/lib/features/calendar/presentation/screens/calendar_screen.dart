import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../shared/widgets/primary_button.dart';
import '../../../../shared/widgets/state_views.dart';
import '../../data/models/event_model.dart';
import '../providers/events_provider.dart';

class CalendarScreen extends ConsumerStatefulWidget {
  const CalendarScreen({super.key});

  @override
  ConsumerState<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends ConsumerState<CalendarScreen> {
  DateTime _focusedDay = DateTime.now();
  DateTime _selectedDay = DateTime.now();

  List<EventModel> _eventsOn(DateTime day, List<EventModel> all) {
    return all.where((e) =>
        e.startTime.year == day.year && e.startTime.month == day.month && e.startTime.day == day.day).toList()
      ..sort((a, b) => a.startTime.compareTo(b.startTime));
  }

  @override
  Widget build(BuildContext context) {
    final eventsAsync = ref.watch(eventsListProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Calendar')),
      body: eventsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => ErrorStateView(
          message: err.toString(),
          onRetry: () => ref.read(eventsListProvider.notifier).refresh(),
        ),
        data: (events) {
          final selectedDayEvents = _eventsOn(_selectedDay, events);
          return Column(
            children: [
              TableCalendar<EventModel>(
                firstDay: DateTime.now().subtract(const Duration(days: 365)),
                lastDay: DateTime.now().add(const Duration(days: 365)),
                focusedDay: _focusedDay,
                selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
                eventLoader: (day) => _eventsOn(day, events),
                calendarFormat: CalendarFormat.month,
                onDaySelected: (selected, focused) {
                  setState(() {
                    _selectedDay = selected;
                    _focusedDay = focused;
                  });
                },
                headerStyle: const HeaderStyle(
                  formatButtonVisible: false,
                  titleCentered: true,
                  titleTextStyle: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                ),
                calendarStyle: CalendarStyle(
                  todayDecoration: BoxDecoration(color: AppColors.primary.withOpacity(0.4), shape: BoxShape.circle),
                  selectedDecoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
                  markerDecoration: const BoxDecoration(color: AppColors.secondary, shape: BoxShape.circle),
                  weekendTextStyle: const TextStyle(color: AppColors.textSecondary),
                  defaultTextStyle: const TextStyle(color: AppColors.textPrimary),
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: selectedDayEvents.isEmpty
                    ? const EmptyStateView(
                        icon: Icons.event_available_outlined,
                        title: 'No events on this day',
                        subtitle: 'Tap + to plan something.',
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: selectedDayEvents.length,
                        itemBuilder: (context, index) {
                          final event = selectedDayEvents[index];
                          return Card(
                            margin: const EdgeInsets.only(bottom: 10),
                            child: ListTile(
                              leading: Container(
                                width: 4,
                                decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(2)),
                              ),
                              title: Text(event.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                              subtitle: Text(
                                event.allDay
                                    ? 'All day'
                                    : '${DateFormat.jm().format(event.startTime)} – ${DateFormat.jm().format(event.endTime)}'
                                        '${event.location != null ? ' · ${event.location}' : ''}',
                                style: const TextStyle(fontSize: 12),
                              ),
                              trailing: IconButton(
                                icon: const Icon(Icons.delete_outline_rounded, size: 20),
                                onPressed: () => ref.read(eventsListProvider.notifier).deleteEvent(event.id),
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (_) => _AddEventSheet(initialDate: _selectedDay),
        ),
        child: const Icon(Icons.add_rounded),
      ),
    );
  }
}

class _AddEventSheet extends ConsumerStatefulWidget {
  const _AddEventSheet({required this.initialDate});
  final DateTime initialDate;

  @override
  ConsumerState<_AddEventSheet> createState() => _AddEventSheetState();
}

class _AddEventSheetState extends ConsumerState<_AddEventSheet> {
  final _titleController = TextEditingController();
  final _locationController = TextEditingController();
  late TimeOfDay _startTime;
  late TimeOfDay _endTime;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    final now = TimeOfDay.now();
    _startTime = now;
    _endTime = TimeOfDay(hour: (now.hour + 1) % 24, minute: now.minute);
  }

  Future<void> _pickTime(bool isStart) async {
    final picked = await showTimePicker(context: context, initialTime: isStart ? _startTime : _endTime);
    if (picked == null) return;
    setState(() {
      if (isStart) {
        _startTime = picked;
      } else {
        _endTime = picked;
      }
    });
  }

  Future<void> _save() async {
    if (_titleController.text.trim().isEmpty) return;
    setState(() => _isSaving = true);
    final start = DateTime(
      widget.initialDate.year,
      widget.initialDate.month,
      widget.initialDate.day,
      _startTime.hour,
      _startTime.minute,
    );
    final end = DateTime(
      widget.initialDate.year,
      widget.initialDate.month,
      widget.initialDate.day,
      _endTime.hour,
      _endTime.minute,
    );
    await ref.read(eventsListProvider.notifier).createEvent(
          title: _titleController.text.trim(),
          location: _locationController.text.trim(),
          startTime: start,
          endTime: end.isAfter(start) ? end : start.add(const Duration(hours: 1)),
        );
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: const BoxDecoration(
          color: AppColors.surfaceElevated,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('New event · ${DateFormat.yMMMd().format(widget.initialDate)}',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            TextField(controller: _titleController, autofocus: true, decoration: const InputDecoration(hintText: 'Event title')),
            const SizedBox(height: 12),
            TextField(controller: _locationController, decoration: const InputDecoration(hintText: 'Location (optional)')),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => _pickTime(true),
                    child: Text('Start: ${_startTime.format(context)}'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => _pickTime(false),
                    child: Text('End: ${_endTime.format(context)}'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            PrimaryButton(label: 'Add event', isLoading: _isSaving, onPressed: _save),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}
