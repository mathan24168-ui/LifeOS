import '../../../../core/network/api_client.dart';
import '../models/event_model.dart';

/// Talks to backend Events endpoints (built in backend Phase 3):
/// GET/POST /events, PUT/DELETE /events/:id
class EventsRepository {
  EventsRepository({required ApiClient apiClient}) : _api = apiClient;

  final ApiClient _api;

  Future<List<EventModel>> fetchEvents({DateTime? from, DateTime? to}) async {
    final response = await _api.get('/events', queryParameters: {
      if (from != null) 'from': from.toIso8601String(),
      if (to != null) 'to': to.toIso8601String(),
    });
    final list = response.data as List;
    return list.map((e) => EventModel.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<EventModel> createEvent({
    required String title,
    String? description,
    String? location,
    required DateTime startTime,
    required DateTime endTime,
    bool allDay = false,
  }) async {
    final response = await _api.post('/events', data: {
      'title': title,
      if (description != null && description.isNotEmpty) 'description': description,
      if (location != null && location.isNotEmpty) 'location': location,
      'start_time': startTime.toIso8601String(),
      'end_time': endTime.toIso8601String(),
      'all_day': allDay,
    });
    return EventModel.fromJson(response.data as Map<String, dynamic>);
  }

  Future<void> deleteEvent(String id) => _api.delete('/events/$id');
}
