import '../../../../core/network/api_client.dart';
import '../models/search_result_model.dart';

/// Talks to the backend's AI Search endpoint (built in backend Phase 4):
/// GET /search?q=... — searches across notes, tasks, and conversations.
class SearchRepository {
  SearchRepository({required ApiClient apiClient}) : _api = apiClient;

  final ApiClient _api;

  Future<List<SearchResultModel>> search(String query) async {
    if (query.trim().isEmpty) return [];
    final response = await _api.get('/search', queryParameters: {'q': query});
    final list = response.data as List;
    return list.map((e) => SearchResultModel.fromJson(e as Map<String, dynamic>)).toList();
  }
}
