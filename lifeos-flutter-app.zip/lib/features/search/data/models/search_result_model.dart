enum SearchResultType { note, task, conversation }

SearchResultType searchResultTypeFromString(String value) {
  switch (value) {
    case 'task':
      return SearchResultType.task;
    case 'conversation':
      return SearchResultType.conversation;
    default:
      return SearchResultType.note;
  }
}

class SearchResultModel {
  const SearchResultModel({
    required this.id,
    required this.type,
    required this.title,
    required this.snippet,
  });

  final String id;
  final SearchResultType type;
  final String title;
  final String snippet;

  factory SearchResultModel.fromJson(Map<String, dynamic> json) {
    return SearchResultModel(
      id: json['id'] as String,
      type: searchResultTypeFromString(json['type'] as String),
      title: json['title'] as String,
      snippet: json['snippet'] as String? ?? '',
    );
  }
}
