import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/providers/core_providers.dart';
import '../../data/models/search_result_model.dart';
import '../../data/repositories/search_repository.dart';

final searchRepositoryProvider = Provider<SearchRepository>((ref) {
  return SearchRepository(apiClient: ref.watch(apiClientProvider));
});

final searchQueryProvider = StateProvider.autoDispose<String>((ref) => '');

final searchResultsProvider = FutureProvider.autoDispose<List<SearchResultModel>>((ref) async {
  final query = ref.watch(searchQueryProvider);
  if (query.trim().isEmpty) return [];

  // Debounce: wait briefly before firing the request, cancel if the query
  // changes again within the window.
  final completer = Completer<void>();
  final timer = Timer(const Duration(milliseconds: 350), () {
    if (!completer.isCompleted) completer.complete();
  });
  ref.onDispose(() => timer.cancel());
  await completer.future;

  return ref.read(searchRepositoryProvider).search(query);
});
