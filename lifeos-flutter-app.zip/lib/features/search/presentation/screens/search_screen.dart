import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../shared/widgets/state_views.dart';
import '../../data/models/search_result_model.dart';
import '../providers/search_provider.dart';

class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key});

  @override
  ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  IconData _iconFor(SearchResultType type) {
    switch (type) {
      case SearchResultType.note:
        return Icons.note_alt_outlined;
      case SearchResultType.task:
        return Icons.task_alt_rounded;
      case SearchResultType.conversation:
        return Icons.chat_bubble_outline_rounded;
    }
  }

  String _labelFor(SearchResultType type) {
    switch (type) {
      case SearchResultType.note:
        return 'Note';
      case SearchResultType.task:
        return 'Task';
      case SearchResultType.conversation:
        return 'Conversation';
    }
  }

  @override
  Widget build(BuildContext context) {
    final resultsAsync = ref.watch(searchResultsProvider);
    final query = ref.watch(searchQueryProvider);

    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _controller,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'Search notes, tasks, chats...',
            border: InputBorder.none,
            filled: false,
          ),
          onChanged: (value) => ref.read(searchQueryProvider.notifier).state = value,
        ),
      ),
      body: query.trim().isEmpty
          ? const EmptyStateView(
              icon: Icons.search_rounded,
              title: 'AI-powered search',
              subtitle: 'Search across all your notes, tasks, and conversations at once.',
            )
          : resultsAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (err, _) => ErrorStateView(message: err.toString()),
              data: (results) {
                if (results.isEmpty) {
                  return const EmptyStateView(
                    icon: Icons.search_off_rounded,
                    title: 'No results found',
                    subtitle: 'Try a different search term.',
                  );
                }
                return ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: results.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    final result = results[index];
                    return Card(
                      child: ListTile(
                        leading: Icon(_iconFor(result.type), color: AppColors.secondary),
                        title: Text(result.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(result.snippet, maxLines: 2, overflow: TextOverflow.ellipsis),
                        trailing: Chip(
                          label: Text(_labelFor(result.type), style: const TextStyle(fontSize: 10)),
                          padding: EdgeInsets.zero,
                          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}
