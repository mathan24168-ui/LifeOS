import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/router/app_routes.dart';
import '../../core/theme/app_colors.dart';

/// Wraps all authenticated + subscribed screens with a persistent bottom
/// navigation bar. Used as the shell route builder in the go_router config.
class HomeShell extends StatelessWidget {
  const HomeShell({super.key, required this.navigationShell});

  final StatefulNavigationShell navigationShell;

  static const _tabs = [
    (route: AppRoutes.dashboard, icon: Icons.dashboard_outlined, activeIcon: Icons.dashboard_rounded, label: 'Home'),
    (route: AppRoutes.chat, icon: Icons.chat_bubble_outline_rounded, activeIcon: Icons.chat_bubble_rounded, label: 'Chat'),
    (route: AppRoutes.notes, icon: Icons.note_alt_outlined, activeIcon: Icons.note_alt_rounded, label: 'Notes'),
    (route: AppRoutes.tasks, icon: Icons.task_alt_outlined, activeIcon: Icons.task_alt_rounded, label: 'Tasks'),
    (route: AppRoutes.calendar, icon: Icons.calendar_month_outlined, activeIcon: Icons.calendar_month_rounded, label: 'Calendar'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: navigationShell,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: navigationShell.currentIndex,
        onTap: (index) => navigationShell.goBranch(
          index,
          initialLocation: index == navigationShell.currentIndex,
        ),
        items: [
          for (final tab in _tabs)
            BottomNavigationBarItem(
              icon: Icon(tab.icon),
              activeIcon: Icon(tab.activeIcon),
              label: tab.label,
            ),
        ],
      ),
      floatingActionButton: navigationShell.currentIndex == 0
          ? null
          : FloatingActionButton(
              backgroundColor: AppColors.primary,
              onPressed: () => context.push(AppRoutes.search),
              child: const Icon(Icons.search_rounded, color: Colors.white),
            ),
    );
  }
}
