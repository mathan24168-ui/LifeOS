# LifeOS AI — Flutter App

User-facing mobile app for LifeOS AI: AI Chat, Smart Notes, Tasks,
Calendar, AI Search, and a ₹249/month Premium paywall gating all access.

Built with Flutter + Riverpod, talking to the LifeOS AI FastAPI backend.

## What's implemented

- **Auth**: email/password + Google Sign-In, JWT access/refresh with
  automatic silent refresh on 401
- **Paywall**: Razorpay Checkout integration (subscription creation,
  payment, signature verification round-trip to backend) — hard-gates the
  rest of the app per the product requirement (no free tier, no trial)
- **Dashboard**: today's tasks, today's notes, upcoming events, recent
  chats in one aggregated view
- **AI Chat**: persistent conversations with message history, markdown
  rendering for AI replies
- **Smart Notes**: create/edit/delete, AI summarize, AI rewrite-with-instruction
- **Tasks**: priority, due dates, reminders, completed/pending sections
- **Calendar**: month view + daily planner, create/delete events
- **AI Search**: debounced cross-entity search (notes + tasks + conversations)
- **Profile**: name edit, photo upload, subscription status, logout
- Dark, premium-styled theme throughout; bottom-nav shell for the 5 core tabs

## Getting started

See **`BUILD_INSTRUCTIONS.md`** for the complete step-by-step: installing
dependencies, Android config (already done), generating a signed release
APK, and installing it on a device — including the one-time Gradle wrapper
bootstrap and a troubleshooting table for common build errors.

Quick version:

```bash
cp .env.example .env   # fill in API_BASE_URL etc.
flutter pub get
flutter build apk --release
adb install build/app/outputs/flutter-apk/app-release.apk
```

## Project layout

```
lib/
  core/
    constants/   # AppConstants, EnvConfig (.env access)
    network/     # Dio client, token storage, ApiException
    providers/   # shared Riverpod providers (api client, token storage)
    router/      # go_router config + route path constants
    theme/       # dark premium ThemeData + color palette
  features/
    auth/        # login, register, splash, auth state notifier
    paywall/     # Razorpay checkout screen + provider
    dashboard/   # aggregated home screen
    chat/        # conversations list + chat screen
    notes/       # notes list + AI-powered editor
    tasks/       # task list + add-task sheet
    calendar/    # month view + daily planner
    search/      # cross-entity AI search
    profile/     # profile screen
  main.dart
android/         # full Gradle/Manifest/signing config, see BUILD_INSTRUCTIONS.md
tools/
  dart_sanity_check.py   # offline structural linter used during development
```

## Backend contract this app expects

This app was built against the LifeOS AI backend's planned API surface.
Endpoints already implemented in backend Phase 1 (`/auth/*`) are live;
endpoints referenced in later phases (`/subscriptions/*`, `/notes`,
`/tasks`, `/events`, `/conversations`, `/search`, `/dashboard`,
`/users/me`) follow the same conventions and will be built to match — if
any backend route name ends up different, only the relevant repository
file in `lib/features/*/data/repositories/` needs a one-line path update.

## Known limitation of this build pass

This app's Dart code was written and structurally verified (balanced
syntax, resolvable imports, provider cross-references) in an environment
with no Flutter SDK and no network access, so `flutter analyze` /
`flutter pub get` / `flutter build apk` have not actually been executed
against it yet. Run `flutter build apk --release` on your machine per
`BUILD_INSTRUCTIONS.md` — if anything fails, share the exact error and
it'll be fixed immediately.
