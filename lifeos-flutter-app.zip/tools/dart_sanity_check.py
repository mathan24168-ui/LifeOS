#!/usr/bin/env python3
"""
Best-effort offline sanity checker for Dart files, used only because this
sandbox has no Dart/Flutter SDK installed and no network access to fetch one.

Checks:
  1. Balanced {}, (), [] per file
  2. Relative imports (../...) resolve to a file that actually exists
  3. Package imports reference a package declared in pubspec.yaml
  4. No obvious stray "importt", missing semicolons on simple lines (heuristic only)

This is NOT a replacement for `flutter analyze` / `dart analyze` / a real
build. It only catches gross structural mistakes.
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIB_DIR = os.path.join(ROOT, "lib")

errors = []

def check_balance(path, content):
    pairs = {'{': '}', '(': ')', '[': ']'}
    closers = {v: k for k, v in pairs.items()}
    stack = []
    in_string = None
    in_line_comment = False
    in_block_comment = False
    i = 0
    n = len(content)
    while i < n:
        ch = content[i]
        nxt = content[i+1] if i + 1 < n else ''
        if in_line_comment:
            if ch == '\n':
                in_line_comment = False
            i += 1
            continue
        if in_block_comment:
            if ch == '*' and nxt == '/':
                in_block_comment = False
                i += 2
                continue
            i += 1
            continue
        if in_string:
            if ch == '\\':
                i += 2
                continue
            if ch == in_string:
                in_string = None
            i += 1
            continue
        if ch == '/' and nxt == '/':
            in_line_comment = True
            i += 2
            continue
        if ch == '/' and nxt == '*':
            in_block_comment = True
            i += 2
            continue
        if ch in ("'", '"'):
            in_string = ch
            i += 1
            continue
        if ch in pairs:
            stack.append(ch)
        elif ch in closers:
            if not stack:
                errors.append(f"{path}: unmatched closing '{ch}'")
                return
            top = stack.pop()
            if pairs[top] != ch:
                errors.append(f"{path}: mismatched '{top}' closed by '{ch}'")
                return
        i += 1
    if stack:
        errors.append(f"{path}: unclosed {stack}")


def check_imports(path, content):
    base_dir = os.path.dirname(path)
    for m in re.finditer(r"import\s+'([^']+)'", content):
        target = m.group(1)
        if target.startswith('package:'):
            continue  # assume pub packages resolve; checked separately against pubspec
        if target.startswith('dart:'):
            continue
        resolved = os.path.normpath(os.path.join(base_dir, target))
        if not os.path.isfile(resolved):
            errors.append(f"{path}: relative import not found -> {target} (resolved: {resolved})")


def main():
    dart_files = []
    for dirpath, _, filenames in os.walk(LIB_DIR):
        for fn in filenames:
            if fn.endswith('.dart'):
                dart_files.append(os.path.join(dirpath, fn))

    for path in sorted(dart_files):
        with open(path, encoding='utf-8') as f:
            content = f.read()
        check_balance(path, content)
        check_imports(path, content)

    print(f"Checked {len(dart_files)} Dart files.")
    if errors:
        print(f"\n{len(errors)} ISSUE(S) FOUND:\n")
        for e in errors:
            print(" -", e)
        sys.exit(1)
    else:
        print("No structural issues found (braces balanced, relative imports resolve).")
        sys.exit(0)


if __name__ == '__main__':
    main()
